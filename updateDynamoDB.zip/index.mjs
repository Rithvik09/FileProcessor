// import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
// import { nanoid } from "nanoid";

// export const handler = async (event) => {
//   try {
//     console.log('Received event:', JSON.stringify(event, null, 2));  // Log the entire event

//     // Check if event.body exists
//     if (!event.body) {
//       throw new Error('No event body found');
//     }

//     // Parse the body
//     let parsedBody;
//     try {
//       parsedBody = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
//     } catch (parseError) {
//       throw new Error(`Error parsing event body: ${parseError.message}`);
//     }

//     const { inputText, s3Path } = parsedBody;

//     console.log('Parsed inputText:', inputText);  // Log input text
//     console.log('Parsed s3Path:', s3Path);  // Log S3 path

//     const tableName = process.env.TABLE_NAME;
//     console.log('Table name:', tableName);  // Log table name

//     const client = new DynamoDBClient();

//     const params = {
//       TableName: tableName,
//       Item: {
//         id: { S: nanoid() },
//         input_text: { S: inputText },
//         input_file_path: { S: s3Path }
//       }
//     };

//     const result = await client.send(new PutItemCommand(params));
//     console.log('DynamoDB update result:', result);  // Log the result of the update

//     return {
//       statusCode: 200,
//       body: JSON.stringify({ message: 'DynamoDB updated successfully!' })
//     };
//   } catch (error) {
//     console.error('DynamoDB update error:', error);  // Log any errors
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: error.message })
//     };
//   }
// };

import AWS from 'aws-sdk';
const dynamodb = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
  let inputText, s3Path;

  try {
    const body = JSON.parse(event.body);
    inputText = body.inputText;
    s3Path = body.s3Path;
  } catch (error) {
    console.error('JSON parsing error:', error);
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
      },
      body: JSON.stringify({ message: 'Invalid JSON input', error: error.message }),
    };
  }

  const params = {
    TableName: 'FovusTable',
    Item: {
      id: new Date().toISOString(), // or any unique id
      inputText: inputText,
      s3Path: s3Path,
    },
  };

  try {
    await dynamodb.put(params).promise();
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
      },
      body: JSON.stringify({ message: 'DynamoDB update successful' }),
    };
  } catch (error) {
    console.error('DynamoDB update error:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
      },
      body: JSON.stringify({ message: 'DynamoDB update failed', error: error.message }),
    };
  }
};
