import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import { DynamoDBClient, UpdateItemCommand } from '@aws-sdk/client-dynamodb';
import { unmarshall } from '@aws-sdk/util-dynamodb';

const s3 = new S3Client({});
const dynamoDB = new DynamoDBClient({});

export const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    const s3Bucket = 'rithvik-fovus';
    const s3InputKey = event.s3InputKey;
    const dynamoDBTable = 'FovusTable';
    const instanceId = event.instanceId;

    if (!s3InputKey) {
        console.error('Error: s3InputKey is undefined');
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Error: s3InputKey is undefined' })
        };
    }

    const s3OutputKey = `output/${s3InputKey.split('/').pop()}`;

    try {
        // Download file from S3
        const inputFile = await s3.send(new GetObjectCommand({
            Bucket: s3Bucket,
            Key: s3InputKey
        }));
        
        const inputText = await streamToString(inputFile.Body);
        const inputTextLength = inputText.length;

        // Append input text length and write to output file
        const outputText = `${inputText}\nInput Text Length: ${inputTextLength}`;
        await s3.send(new PutObjectCommand({
            Bucket: s3Bucket,
            Key: s3OutputKey,
            Body: outputText
        }));

        // Update DynamoDB with output file path
        await dynamoDB.send(new UpdateItemCommand({
            TableName: dynamoDBTable,
            Key: {
                id: { S: instanceId }
            },
            UpdateExpression: 'SET output_file_path = :path',
            ExpressionAttributeValues: {
                ':path': { S: `s3://${s3Bucket}/${s3OutputKey}` }
            }
        }));

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'File processed and DynamoDB updated successfully' })
        };
    } catch (error) {
        console.error('Error processing file:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'File processing failed', error: error.message })
        };
    }
};

const streamToString = (stream) => new Promise((resolve, reject) => {
    const chunks = [];
    stream.on('data', (chunk) => chunks.push(chunk));
    stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
    stream.on('error', reject);
});
