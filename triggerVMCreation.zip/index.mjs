import AWS from 'aws-sdk';
const ec2 = new AWS.EC2();

export const handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  const params = {
    ImageId: 'ami-0296a329aeec73707',
    InstanceType: 't2.micro',
    MinCount: 1,
    MaxCount: 1,
    KeyName: 'FovusKey',
  };

  console.log('EC2 runInstances params:', JSON.stringify(params, null, 2));

  try {
    const data = await ec2.runInstances(params).promise();
    console.log('EC2 runInstances result:', JSON.stringify(data, null, 2));
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
      },
      body: JSON.stringify({ message: 'EC2 instance creation successful', data: data }),
    };
  } catch (error) {
    console.error('EC2 instance creation error:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
      },
      body: JSON.stringify({ message: 'EC2 instance creation failed', error: error.message }),
    };
  }
};