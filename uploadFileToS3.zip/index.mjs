import AWS from 'aws-sdk';
const s3 = new AWS.S3();

export const handler = async (event) => {
  let fileContent, fileName;

  try {
    const body = JSON.parse(event.body);
    fileContent = body.fileContent;
    fileName = body.fileName;
  } catch (error) {
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*', // Allow from anywhere
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
      },
      body: JSON.stringify({ message: 'Invalid JSON input', error: error.message }),
    };
  }

  const params = {
    Bucket: 'rithvik-fovus', // Replace with your bucket name
    Key: fileName,
    Body: Buffer.from(fileContent, 'base64'),
    ContentEncoding: 'base64',
    ContentType: 'application/pdf', // Adjust this according to your file type
  };

  try {
    await s3.putObject(params).promise();
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*', // Allow from anywhere
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
      },
      body: JSON.stringify({ message: 'File uploaded successfully' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*', // Allow from anywhere
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
      },
      body: JSON.stringify({ message: 'File upload failed', error: error.message }),
    };
  }
};
